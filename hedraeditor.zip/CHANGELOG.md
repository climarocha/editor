
## Alpha 2

- Update to Substance Beta 5
- Front matter editing for title + abstract (JATS `<front>`)
- Editing of authors (create, update and delete contrib elements)
- Create and edit xref elements

## Alpha

Initial release